package comp4342.totp_manager.sync;

public class ConnectionException extends Exception{
    public ConnectionException(String msg){super(msg);}
}
